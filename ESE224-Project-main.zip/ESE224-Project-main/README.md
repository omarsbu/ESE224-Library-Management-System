# ESE224-Midterm-Project

## 11/06/2022
I have added the date counter, debugged everything, and fixed everything to the best of my ability. I slightly tweaked a lot of the functions, and I also reverted some changes because I thought they were simpler and they worked before anyway. Github saves the history of all the versions, so we have the previous versions just in case. 

Everything works in terms of functionality, so I think all we need to do is go through it one time together, and maybe look at edge cases. Now any changes that should be added are aesthetic/visual changes to the display in the console and adding onto the functions to deal with edge cases (so minor changes mostly). With this, the code is pretty much done, so all we need to do is the report and we should be good.

## 11/03/2022
I think we are almost done. Whoever wrote the request and delete teacher functions, can you put a function header and more comments so who ever is going through the program knows what you are doing. Also I wanted to upload the files and then change their names so the old files were still in the github but when I uploaded them it replaced the old files. If your not happy with any of the changes, you can just go the repository's history to see or restore the previous versions. Someone also still needs to do the date counter. Please try to put as many comments as you can when you make changes so other people can go through it and see if anything needs to be changed. 

Also when I run the program, it is not able to open the files. I am not sure if this is an issue with the code or my computer because for whatever reason, my computer doesn't always open files in C++. Whenever you get a chance, can someon run the program on their computer and see how it is. Im pretty sure all thats left to do now is the date counter and a bit of debugging.
